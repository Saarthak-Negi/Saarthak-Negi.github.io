CREATE TABLE IF NOT EXISTS PersonTransfer (
    PTPK INT AUTO_INCREMENT PRIMARY KEY,
    EmpIDFK INT,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Gender CHAR(1),
    DateOfJoining DATE,
    CurrentRegion VARCHAR(20),
    NewRegion VARCHAR(20),
    FOREIGN KEY (EmpIDFK) REFERENCES Person(EmpID)
);

DELIMITER $$

CREATE PROCEDURE populate_PersonTransfer()
BEGIN
    -- Delete existing data from PersonTransfer
    DELETE FROM PersonTransfer;
    
    -- Insert data for female employees with more than 10 years (3650 days) of work experience
    INSERT INTO PersonTransfer (
        EmpIDFK, 
        FirstName, 
        LastName, 
        Gender, 
        DateOfJoining, 
        CurrentRegion, 
        NewRegion
    )
    SELECT 
        EmpID AS EmpIDFK,
        FirstName,
        LastName,
        Gender,
        DateOfJoining,
        Region AS CurrentRegion,
        'DC' AS NewRegion
    FROM 
        Person
    WHERE 
        Gender = 'F' 
        AND DATEDIFF(CURDATE(), DateOfJoining) > 3650;  -- 10 years in days

    -- Insert data for male employees with more than 20 years (7300 days) of work experience
    INSERT INTO PersonTransfer (
        EmpIDFK, 
        FirstName, 
        LastName, 
        Gender, 
        DateOfJoining, 
        CurrentRegion, 
        NewRegion
    )
    SELECT 
        EmpID AS EmpIDFK,
        FirstName,
        LastName,
        Gender,
        DateOfJoining,
        Region AS CurrentRegion,
        'Capitol' AS NewRegion
    FROM 
        Person
    WHERE 
        Gender = 'M' 
        AND DATEDIFF(CURDATE(), DateOfJoining) > 7300;  -- 20 years in days
END $$

DELIMITER ;

-- To run the stored procedure
CALL populate_PersonTransfer();

