CREATE TABLE IF NOT EXISTS PersonJoining (
    PJoinPK INT AUTO_INCREMENT PRIMARY KEY,
    EmpIDFK INT,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    DateOfBirth DATE,
    Age INT,
    DateOfJoining DATE,
    DayOfJoining INT,
    MonthOfJoining VARCHAR(15),
    YearOfJoining INT,
    WorkExpinDays INT,
    FOREIGN KEY (EmpIDFK) REFERENCES Person(EmpID)
);

DELIMITER $$

CREATE PROCEDURE populate_PersonJoining()
BEGIN
    -- Delete existing data from PersonJoining
    DELETE FROM PersonJoining;
    
    -- Insert new data into PersonJoining table with calculated fields
    INSERT INTO PersonJoining (
        EmpIDFK, 
        FirstName, 
        LastName, 
        DateOfBirth, 
        Age, 
        DateOfJoining, 
        DayOfJoining, 
        MonthOfJoining, 
        YearOfJoining, 
        WorkExpinDays
    )
    SELECT 
        EmpID AS EmpIDFK,
        FirstName,
        LastName,
        DateOfBirth,
        
        -- Calculate age using DateOfBirth
        TIMESTAMPDIFF(YEAR, DateOfBirth, CURDATE()) AS Age,
        
        DateOfJoining,
        
        -- Extract day, month name, and year from DateOfJoining
        DAY(DateOfJoining) AS DayOfJoining,
        MONTHNAME(DateOfJoining) AS MonthOfJoining,
        YEAR(DateOfJoining) AS YearOfJoining,
        
        -- Calculate work experience in days
        DATEDIFF(CURDATE(), DateOfJoining) AS WorkExpinDays
    FROM 
        Person;
END $$

DELIMITER ;

-- To run the stored procedure
CALL populate_PersonJoining();

