CREATE TABLE Person (
    EmpID INT PRIMARY KEY,
    NamePrefix VARCHAR(10),
    FirstName VARCHAR(50),
    MiddleInitial CHAR(1),
    LastName VARCHAR(50),
    Gender CHAR(1),
    Email VARCHAR(100),
    FathersName VARCHAR(50),
    MothersName VARCHAR(50),
    MothersMaidenName VARCHAR(50),
    DateOfBirth DATE,
    TimeOfBirth TIME,
    WeightInKg DECIMAL(5, 2),
    DateOfJoining DATE,
    Salary DECIMAL(10, 2),
    LastHike DECIMAL(5, 2),
    PlaceName VARCHAR(100),
    County VARCHAR(100),
    City VARCHAR(100),
    State VARCHAR(5),
    Region VARCHAR(20)
);

-- Load data from the CSV file into the 'Person' table
LOAD DATA INFILE '/path_to/empdetails.csv'
INTO TABLE Person
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(
    EmpID, NamePrefix, FirstName, MiddleInitial, LastName, Gender, 
    Email, FathersName, MothersName, MothersMaidenName, 
    DateOfBirth, TimeOfBirth, WeightInKg, DateOfJoining, 
    Salary, LastHike, PlaceName, County, City, State, Region
);

