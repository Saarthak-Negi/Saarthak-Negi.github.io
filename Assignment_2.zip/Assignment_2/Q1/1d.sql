SELECT 
    Region AS EmployeeRegion,
    
    -- Count of employees born between 00:00 and 09:00 hours
    SUM(CASE 
        WHEN TIME(TimeOfBirth) BETWEEN '00:00:00' AND '09:00:00' 
        THEN 1 
        ELSE 0 
    END) AS 'No. Of Employee born between 00:00 hours to 09:00 hours',
    
    -- Count of employees born between 09:01 and 16:00 hours
    SUM(CASE 
        WHEN TIME(TimeOfBirth) BETWEEN '09:01:00' AND '16:00:00' 
        THEN 1 
        ELSE 0 
    END) AS 'No. Of Employee born between 09:01 hours to 16:00 hours',
    
    -- Count of employees born between 16:01 and 22:59 hours
    SUM(CASE 
        WHEN TIME(TimeOfBirth) BETWEEN '16:01:00' AND '22:59:00' 
        THEN 1 
        ELSE 0 
    END) AS 'No. Of Employees born after 16:01 hours until 22:59 hours'
    
FROM 
    Person
GROUP BY 
    Region;

