awk '/POST/&&/404/' IGNORECASE=0 access.log
